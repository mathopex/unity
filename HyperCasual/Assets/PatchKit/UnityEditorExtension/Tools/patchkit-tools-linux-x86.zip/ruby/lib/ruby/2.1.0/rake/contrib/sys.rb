fail "ERROR: 'rake/contrib/sys' is obsolete and no longer supported. " +
  "Use 'FileUtils' instead."
